.. Plyer documentation master file, created by
   sphinx-quickstart on Wed Jul  3 15:18:02 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Plyer
================

Plyer is a Python library for accessing features of your hardware / platforms.

.. automodule:: plyer
    :members:

.. automodule:: plyer.facades
    :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

